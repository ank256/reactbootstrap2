import React from 'react'
import './banner.css';



function Footer() {
  return (
    <div className='container-fluid ps-5 pe-5 d-flex footermargin'>
        <div className='row'>
            <div className='col-lg-4'>
      <img src='https://reveation-website-2023-strapi.s3.amazonaws.com/reveation_logo_2_6a5aeb7590.svg' className='footerlogo' alt='footer logo' />
     <h5 className='fw-bold text-primary pt-4'>Location</h5>
     
     <h6 style={{ lineHeight: '25px' }} className='text-muted'>5700 Tennyson Parkway, Suite 300, Plano, TX,<br /> 75024, USA</h6>

     <h5 className='text-primary fw-bold pt-4'>Email</h5>

     <h6 className='text-muted'>sales@reveation.io</h6>
     <h5 className='text-primary fw-bold pt-4'>Contact</h5>
     <h6 className='text-muted'>+1-8570254601 (USA)</h6>
     <h6 className='text-muted'>+91-9913906488 (India)</h6>

      </div>
      </div>



      {/* <div>
    <h5 className='mb-3 text-primary fw-bold'>Services</h5>
      </div> */}
    </div>
  )
}

export default Footer
