import React from 'react'

function ResultDrivenRender({img,imgone}) {
  return (
    <>
      <img src={img} alt='image' />
      <img src={imgone} className='me-5' alt='image' />
      </>
  )
}

export default ResultDrivenRender
