import React from 'react'
import image from '../happyclients.json'


function HappyClients() {
  return (
    <>
    <div className='container-fluid'>
        <img className='happy'  src="https://oyster-app-a4gal.ondigitalocean.app/_nuxt/element4.DeS2qNd1.svg" alt="Slide" />
       <h1 className='fw-bold trusted'>Trusted by</h1>
   <h1 className='text-primary fw-bold clients'>Happy Clients</h1>  

   <div className='container-fluid slider marquee-contentthree d-flex align-items-center' >
   {image.map((happy) =>(
     
     <img className='slideimagetwo' key={happy.id} src={happy.imgone} alt="Slide" />
   ))}
    </div>
    </div>
    <div className=''>
    <img className='h-w-100 my-5'  src="data:image/svg+xml,%3csvg%20width='1920'%20height='182'%20viewBox='0%200%201920%20182'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M-48%2023.69C515.108%20220.959%201433.92%20217.671%201968%2012'%20stroke='url(%23paint0_linear_29_1159)'%20stroke-width='25'/%3e%3cdefs%3e%3clinearGradient%20id='paint0_linear_29_1159'%20x1='13'%20y1='164.589'%20x2='1991'%20y2='164.589'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20stop-color='%231B2B80'/%3e%3cstop%20offset='0.220033'%20stop-color='%233656FF'/%3e%3cstop%20offset='0.708952'%20stop-color='%233352F3'/%3e%3cstop%20offset='1'%20stop-color='%231A2873'/%3e%3c/linearGradient%3e%3c/defs%3e%3c/svg%3e" alt="Slide" />
    </div>
    </>
  );


}

export default HappyClients
