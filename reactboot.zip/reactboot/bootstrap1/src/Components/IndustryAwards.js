import React from 'react'
import Dashedline from './dashedline.js'
import './banner.css';
import Slideimage from './slideimage.js';

function IndustryAwards() {
  return (
    <div className='container-fluid awards p-5'>
       <h1 className='text-white fw-bold text-center mb-5 heading'>Industry Recognitions and Awards</h1>
       <div className='border border-1 border-white m-auto rounded-pill bord'>
       <h6 className='py-2 px-4 mb-0 text-white text-center'>GoodFirms Recognizes Reveation Labs as Top Blockchain Development Company in the USA</h6>
       </div>
       <Dashedline />
       <Slideimage />
    </div>
  );
}

export default IndustryAwards;
