import React from 'react'
import './banner.css';
import image from '../imagetwo.json';
import ExelRender from './ExelRender';


function Exel() {
  return (
    <div className='container-fluid'>
        <h1 className='exel mt-5'>What <span className='we'>We Excel At</span></h1>
        
    <div className='row'>
        
{image.map((happy) => (
    
<ExelRender
                key={happy.id}
                img={happy.img}
                colSize={`col-lg-${happy.colSize}`}
                
                
              />
                
            ))}
    </div>
  
    </div>
    
  );}


export default Exel;
