import React from 'react'
import image from '../experienced.json'
import Button from './button';
import ExperiencedRender from './ExperiencedRender';

function Experienced() {
  return (
    
        <div className='container-fluid gradientexp'>
        <div className='row'>
            <div className='col-lg-6'>
                <h1 className='fw-bold text-white heading'>Companies experienced 5x faster growth with our remote tech teams</h1>
                <h6 className='fw-bold text-white subheading'>Hire Top-tier Software Developers on Contract Today</h6>
                <h6 className='text-white mt-5 pb-5 para2'>Join the ranks of successful enterprises and fast-scaling startups who have reaped the benefits of our on-demand developer solutions. Our senior, pre-vetted developers offer robust technical and communication skills at unbeatable rates, tailored to suit your timezone.</h6>

                <Button title="Hire Remote Developers" className="bannerBut text-primary fw-bold rounded-pill" />

            </div>
            <div className='col-lg-6'>
                {image.map((happy) => (
          <ExperiencedRender 
          
          key={happy.id}
          img={happy.img}
          
          
          /> 
          
                ))}
                
                <img className="firstimg img1" src='https://reveation-website-2023-strapi.s3.amazonaws.com/craft_d4428f2805_2_6db8c530eb.svg' alt='globeimg' />
                <h6 className='globetext globetext1'>Power Bi</h6>
                
                <div>
                <img className="firstimg img2" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_23e5a13d05.svg'g alt='globeimg' />
                <h6 className='globetext globetext2'>Sharepoint</h6>
                </div>
                <div>
                <img className="firstimg img3" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_2_de0a071252.svg' alt='globeimg' />
                <h6 className='globetext globetext3'>React js</h6>
                </div>
                <div>
                <img className="firstimg img4" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_3_3772cafdbb.svg' alt='globeimg' />
                <h6 className='globetext globetext4'>Python</h6>
                </div>
                <div>
                <img className="firstimg img5" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_1_0f85f8cb70.svg' alt='globeimg' />
                <h6 className='globetext globetext5'>nuxt js</h6>
                </div>
                <div>
                <img className="firstimg img6" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_8_14748486a1.svg' alt='globeimg' />
                <h6 className='globetext globetext6'>Blockchain</h6>
                </div>
                <div>
                <img className="firstimg img7" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_7_b23f71b101.svg' alt='globeimg' />
                <h6 className='globetext globetext7'>Svelte</h6>
                </div>
                <div>
                <img className="firstimg img8" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_4_07c4e50419.svg' alt='globeimg' />
                <h6 className='globetext globetext8'>Dot Net</h6>
                </div>
                <div>
                <img className="firstimg img9" src='https://reveation-website-2023-strapi.s3.amazonaws.com/Ellipse_111_6_9d767bd428.svg' alt='globeimg' />
                <h6 className='globetext globetext9'>Vue Js</h6>
                </div>
            </div>
        </div>
        </div>
    
  )
}

export default Experienced
