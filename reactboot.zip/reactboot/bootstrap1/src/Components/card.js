import React from 'react'

import './banner.css';
import Button from './button';



 


 function MyCard(props) {
  return (
    <div className="col-md-6 pb-5">
      <div className="shadow card p-3 h-100 rounded border-0">
        <div className='row'>
          <div className='col-8'>
          <h3 className="fw-bold  lign-height  text-center text-md-start">
            <span className="text-black  pe-2">{
              props.heading.split(' ').slice(0, -2).join(' ')
            }</span>
            <span className="text-primary">{
              props.heading.split(' ').slice(-2).join(' ')
            }</span>
          </h3>
          </div>
          <div className='col-4 pb-5 d-flex justify-content-end'>
          <img className='cardImg' src={props.img} alt="Card Image" />
          </div>
        </div>
        <div style={{color: '#7c7c7c'}} className='font-size-md-16  font-size-12 fw-bold'>
      <p>{props.text}</p>
      <div className='cardImage'></div>
      <Button title="Explore" icon="arrow-right ms-2 mt-1" className="text-black border-2 mt-5 rounded-pill px-3 py-1 bg-white d-flex flex-row align-items-center" />
      



      </div>
      </div>
      </div>
  );
}
export default MyCard;