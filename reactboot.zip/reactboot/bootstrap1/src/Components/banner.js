import React from 'react';
import './banner.css';
 import Image from 'react-bootstrap/Image';
 import 'bootstrap/dist/css/bootstrap.min.css';
 import { Container, Row, Col } from 'react-bootstrap';
 import Button from './button';

function Banner() {
  return (
    <div>
      <div className="container-fluid d-flex ban">
        <div className="row">
        <div className="col-md-2 d-flex justify-content-start align-items-center">
      <img className="rgtimg" src="https://oyster-app-a4gal.ondigitalocean.app/_nuxt/banner_element_left.1J5QLCh_.svg"/>
      </div>
           
      <div className="col-md-8 d-flex text-center align-items-center">
        <div className='row'>
      <h1 className="main">NextGen Software <br /> <span className="webkit">Solutions</span></h1> 
         <p className=' para'> Trusted by Leading Enterprises and Promising Startups</p> 
         <Button title="Get In Toch" className="bannerBut text-primary fw-bold rounded-pill" />
      </div>
      </div>
      <div className="col-md-2 d-flex justify-content-end align-items-center">
      <img className="rgtimg" src="https://oyster-app-a4gal.ondigitalocean.app/_nuxt/banner_element_right.Shba63is.svg"/>
      </div>
    
      </div>
    </div>
    </div>
  )
}

export default Banner;
