import React from 'react'
import './banner.css';
import data from '../icon.json';
import BlueLineRender from './BlueLineRender';

function BlueLine() {
  return (
    <div  className='bg-primary w-100 mt-5'>
      <div className='text-white  marquee-contenttwo'>
        <div className='d-flex align-items-center ms-3 marquee-item'>
        {data.map((happy) => (
        <BlueLineRender 
       
        key = {happy.id}
        img= {happy.img}
        text= {happy.content}
        />
      ))}
      </div>
      </div>
      </div>
    )}
      
 


export default BlueLine;
