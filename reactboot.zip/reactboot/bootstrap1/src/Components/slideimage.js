import React from 'react'
import image from '../image.json';

function Slideimage() {
  return (
    <div className='marquee '>
  <div className='marquee-content '>
      {image.map((happy) => ( 

<img className='bg-white slideimage  p-2 rounded-circle' key={happy.id} src={happy.img} alt="Slide" />
               
                 ))}
    </div>
    </div>
  );
}

export default Slideimage
