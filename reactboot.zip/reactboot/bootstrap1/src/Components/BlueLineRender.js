// import React from 'react'
// import './banner.css';

// function BlueLineRender(props) {
//   return (
//          <div className='bg-primary w-100'>
//         <div className='  d-flex align-items-center text-white'>
//       <img src={props.img} alt="iconimg"/>
//       <p className='content'>{props.text}</p>
//     </div>
//     </div>
//   )
// }

// export default BlueLineRender


import React from 'react';
import './banner.css';

function BlueLineRender({ img, text }) {
  return (
    <div className='d-flex align-items-center'>
      <img src={img} alt="iconimg" className='icon-img' />
      <p className='ms-3 marquee-text me-2'>{text}</p>
    </div>
  );
}

export default BlueLineRender;
