import React from 'react'
import ResultDrivenRender from './ResultDrivenRender'
import image from '../resultdriven.json';
function ResultDriven() {
  return (
   <>
      <h1 className='result text-center mt-5 fw-bold'>Result Driven <span className='Journey'>Journey</span></h1>
      
      <div className='container rotate w-100 h-100 my-5 gap-3 d-flex justify-content-center'>

      {image.map((happy) =>(
       


        <ResultDrivenRender  
        
        
            key={happy.id}
            img={happy.img}
            imgone={happy.imgone}
             /> 
        
        ))}
       
    
    </div>
    </>
  )
}

export default ResultDriven
