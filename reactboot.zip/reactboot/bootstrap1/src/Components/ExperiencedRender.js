import React from 'react'
import './banner.css';

function ExperiencedRender(props) {
  return (
    <div>
       <img className='globeimg' src={props.img} alt="Globe Image" />
       
    </div>
  )
}

export default ExperiencedRender
