import React from 'react'
import './banner.css';




function ExelRender({ img, colSize }) {
    
  return (
    
    <div className={colSize} img-container>
            
                <img className='object-fit w-100 h-100 gy-3' src={img} alt="Slide"   />
                     </div>
   
  );
}

export default ExelRender;
