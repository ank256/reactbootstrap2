import React from 'react';
import './banner.css';

function Button(props) {
  return (
    <div>
      <button className={props.className}>
        {props.title}
        {props.icon && <i className={`fas fa-${props.icon}`}></i>}
      </button>
    </div>
  );
}

export default Button;
