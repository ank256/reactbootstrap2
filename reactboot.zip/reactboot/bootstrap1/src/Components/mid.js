import React from 'react'
import MyCard from '../Components/card';
import data from '../data.json';

function Mid() {
  return (
    <div>
        <div className="container-fluid mt-5">
      <div className="row">
        <div className="col-md-7 ps-5">
          <div className="row">
            {data.map((happy) => (
              <MyCard
                key={happy.id}
                img={happy.img}
                heading={happy.heading}
                text={happy.text}
                
              />
              
            ))}
          </div>
        </div>
        <div className="col-md-5 d-flex justify-content-end">
          <img className="w-75" src="https://oyster-app-a4gal.ondigitalocean.app/_nuxt/triangle_element.JKDP3Kic.svg"/>
        </div>
      </div>
    </div>
    </div>
  );
}

export default Mid
