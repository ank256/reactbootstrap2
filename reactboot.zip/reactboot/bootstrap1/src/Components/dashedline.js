import React from 'react'
import './banner.css';

function Dashedline() {
  return (
    
       <div className="dashed-line"></div>
    
  )
}

export default Dashedline
