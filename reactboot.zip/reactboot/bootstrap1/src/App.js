import React from 'react'
import Mid from './Components/mid';
import Banner from './Components/banner';
import IndustryAwards from './Components/IndustryAwards';
import Exel from './Components/Exel';
import BlueLine from './Components/BlueLine';
import 'bootstrap/dist/css/bootstrap.min.css';
import ResultDriven from './Components/ResultDriven';
import HappyClients from './Components/HappyClients';
import Experienced from './Components/Experienced';
import Footer from './Components/Footer';
function App() {
  return (
    <div>
    
      <Banner/>
       <Mid/>
        {/* <ResultDriven /> */}
        <IndustryAwards/>
        <BlueLine />
        <HappyClients/>
        <Exel/>
        <Experienced />
        <Footer />
    </div>
  )
}

export default App;
  